(function($) {
    "use strict"

    CKEDITOR.replace('ck_editor');




})(jQuery);